import { header } from "./src/componentes/header"



document.querySelector('header').innerHTML = header.template
header.script()

