export const objetosBD = [
    {
        codigo: '123456',
        fecha: '01/04/2023',
        fechaResuelto: '01/12/2023',
        aula: 'T1',
        grupo: 'DAW2',
        ordenador: 'PC1',
        descripcion: 'Error de pantalla',
        alumno: 'Ejemplo Ejemplin',
        estado: 'resuelto'
        
    },
    {
        codigo: '123456',
        fecha: '01/04/2023',
        fechaResuelto: '01/12/2023',
        aula: 'T1',
        grupo: 'DAW2',
        ordenador: 'PC1',
        descripcion: 'Error de pantalla',
        alumno: 'Ejemplo Ejemplin',
        estado: 'resuelto'
        
    },
    {
        codigo: '123456',
        fecha: '01/04/2023',
        fechaResuelto: '01/12/2023',
        aula: 'T1',
        grupo: 'DAW2',
        ordenador: 'PC1',
        descripcion: 'Error de pantalla',
        alumno: 'Ejemplo Ejemplin',
        estado: 'resuelto'
        
    },
    {
        codigo: '123456',
        fecha: '01/04/2023',
        aula: 'T1',
        grupo: 'DAW2',
        ordenador: 'PC1',
        descripcion: 'Error de pantalla',
        alumno: 'Ejemplo Ejemplin',
        estado: 'pendiente'
        
    },
    {
        codigo: '123456',
        fecha: '01/04/2023',
        aula: 'T1',
        grupo: 'DAW2',
        ordenador: 'PC1',
        descripcion: 'Error de pantalla',
        alumno: 'Ejemplo Ejemplin',
        estado: 'pendiente'
        
    },
]