export const panel = (codigo,fecha,aula,grupo,ordenador,descripcion,alumno,estado) => {
    const template = //
}