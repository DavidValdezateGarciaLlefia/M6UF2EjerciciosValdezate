import { vistaLogin } from "./vistaLogin"


export const vistaRegistro = {
    template: //html
    `
    <h1>Registrate</h1>

    <div class="container d-flex justify-content-center align-items-center vh-100">
          <form novalidate action="procesa.php" method="get" class="form border p-3 shadow w-25 ">
              <label for="email" class="label-control">Usuario:</label>
              <input required id="email" name="email" type="email" placeholder="tuemail@ejemplo.com" class="form-control">
              <div class="invalid-feedback small">Esta mal</div>
              <div class="valid-feedback">Esta bien</div>
              <label for="pass" class="label-control">Contraseña:</label>
              <input required minlength="4" id="pass"  name="pass" type="password" class="form-control">
              <div class="invalid-feedback">La contraseña debe tener mínimo 3 carácteres</div>
              <button id="registros" class="btn btn-success mt-3 w-100" >Enviar</button>
          </form>
  
      </div>
    `,
    script:()=>{
        
      const formulario = document.querySelector('form')
      formulario.addEventListener('submit', (event) => {
          if (!formulario.checkValidity()) {
              // Detenemos la propagación del evento  
              event.preventDefault()
              event.stopPropagation()
              // Añadimos al formulario la clase was-validated
              console.log('El formulario no es válido');
              
              formulario.classList.add('was-validated')
          } else {
              event.preventDefault()
              document.querySelector('main').innerHTML = vistaLogin.template
              vistaLogin.script()
          }
        })
    }
  
    
  }